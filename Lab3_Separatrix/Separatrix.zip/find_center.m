function [center] = find_center(inputArg1, inputArg2)
    center = inputArg1 + (inputArg2 - inputArg1) / 2
end